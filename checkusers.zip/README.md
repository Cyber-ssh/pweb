# MULTI-checkUsers


```
bash <(curl -sL https://raw.githubusercontent.com/Cyber-ssh/checkusers/main/instcheck.sh) && chall
```
