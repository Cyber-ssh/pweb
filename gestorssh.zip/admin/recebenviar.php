<?php
require_once('../admin/pages/botbackup/config.php');

$currentDir = dirname(__FILE__);

require_once($currentDir . '/../pages/system/seguranca.php');

if (empty($telegramToken) || empty($telegramUserId)) {
    echo 'Token do Bot do Telegram ou ID do Usuário não configurados.';
    exit;
}

$dbServer = $_SG['servidor'];  
$dbUser = $_SG['usuario'];  
$dbPassword = $_SG['senha']; 
$dbName = $_SG['banco'];  

function gerarBackup($dbServer, $dbUser, $dbPassword, $dbName)
{

    $dsn = "mysql:host=$dbServer;dbname=$dbName;charset=utf8";

    try {

        $pdo = new PDO($dsn, $dbUser, $dbPassword);

        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $backupFile = 'backup-' . date('Y-m-d') . '.sql';

        exec("mysqldump --single-transaction --host=$dbServer --user=$dbUser --password=$dbPassword $dbName > $backupFile");

        return $backupFile;
    } catch (PDOException $e) {
        echo 'Erro ao gerar o backup do banco de dados: ' . $e->getMessage();
        exit;
    }
}

$backupFile = gerarBackup($dbServer, $dbUser, $dbPassword, $dbName);

function enviarBackupTelegram($telegramToken, $telegramUserId, $backupFile)
{

    $telegramApiUrl = "https://api.telegram.org/bot$telegramToken/sendDocument";

    $backupData = [
        'chat_id' => $telegramUserId,
        'document' => new CURLFile($backupFile),
        'caption' => 'Aqui está o seu backup diário!'
    ];

    $curl = curl_init($telegramApiUrl);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $backupData);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($curl);

    if ($response === false) {
        echo 'Erro ao enviar o backup para o Telegram: ' . curl_error($curl);
        exit;
    }

    curl_close($curl);

    unlink($backupFile);

    echo '<script>alert("Backup enviado com sucesso!"); window.history.back();</script>';
}

enviarBackupTelegram($telegramToken, $telegramUserId, $backupFile);
