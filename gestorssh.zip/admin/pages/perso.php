<style type="text/css">
.perso {
	background-color: aqua;
	border: solid 1px black;
	border-radius: 50px;
	height: 30px;
	color: #FFF;
}
.btapp {
	color: #333;
	background-color: aqua;
	border: solid 1px black;
	border-radius: 50px;
	height: 30px;
}
#multiple-column-form .row .col-12 .card .card-header .card-title {
	color: #F00;
}
</style>
<section id="multiple-column-form">
    <div class="row">
    <div class="col-12">
    <div class="card">
    <div class="card-header">
    <h5 class="card-title">MENU DE PERSONALIZAR</h5>
	<p class="px-0"><b>Tamanho recomendado (1980px x 1080px).png ou jpg</b>
					
	<p class="px-0"><b>Após fazer as alterações limpe o Cache/Dados do Navegador para aparecer.</b>
    </div>
    
    <div class="card-body">
    <center><p class="px-0"><b>ALTERAR FUNDO DO REVENDA.</b></p></center>
    <div class="alert-info">					
    </div>
    <p> 
    </p>     

    <form method="post" enctype="multipart/form-data" action="recebeBkrv.php">
	<center><input name="arquivo" type="file" class="post" />
    <input type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light" value="Salvar" /> </center><br/>
	<p>
	</p>
    </form>
    </div>
    
    <center><p class="px-0"><b>ALTERAR FUNDO DO ADMIN.</b></p></center>
    <div class="alert-info">					
    </div>
    <p> 
    </p>     
    <form method="post" enctype="multipart/form-data" action="recebeBkad.php">
	<center><input name="arquivo" type="file" class="post" />
    <input type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light" value="Salvar" /> </center><br/>
	<p>
	</p>		
    </form>
    </br>
    
<center><p class="px-0"><b>ALTERAR FUNDO DA LOJA.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebeStore.php">
       
	<center><input name="arquivo" type="file" class="post" />
    <input type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light" value="Salvar" /> </center><br/>
    </form>
<center><p class="px-0"><b>ALTERAR LOGO PRINCIPAL.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebelogo1.php">
       
	  <center><input name="arquivo" type="file" class="post" />
       <input type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light" value="Salvar" /> </center><br/>
    </form>	
  
 <center><p class="px-0"><b>ALTERAR LOGO REVENDA 1.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebelogo2.php">
       
	  <center><input name="arquivo" type="file" class="post" />
       <input type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light" value="Salvar" /> </center><br/>
    </form>
    
    
    <center><p class="px-0"><b>ALTERAR LOGO REVENDA 2.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebelogo3.php">
       
	  <center><input name="arquivo" type="file" class="post" />
       <input type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light" value="Salvar" /> </center><br/>
    </form>
    
    
    <center><p class="px-0"><b>ALTERAR LOGO REVENDA 3.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebelogo4.php">
       
	  <center><input name="arquivo" type="file" class="post" />
       <input type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light" value="Salvar" /> </center><br/>
    </form>	
    
    
    <center><p class="px-0"><b>ALTERAR LOGO REVENDA 4.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebelogo5.php">
       
	  <center><input name="arquivo" type="file" class="post" />
       <input type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light" value="Salvar" /> </center><br/>
    </form>	
    
    
    <center><p class="px-0"><b>ALTERAR LOGO REVENDA 5.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebelogo6.php">
       
	  <center><input name="arquivo" type="file" class="post" />
       <input type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light" value="Salvar" /> </center><br/>
    </form>
    
        <center><p class="px-0"><b>ALTERAR AVATAR.</b></p></center>
<div class="alert-info">						
</div>
<p> 
</p>     
<form method="post" enctype="multipart/form-data" action="recebelogo7.php">
       
	  <center><input name="arquivo" type="file" class="post" />
       <input type="submit" class="btn btn-success me-1 waves-effect waves-float waves-light" value="Salvar" /> </center><br/>
    </form>	
                </div>
            </div>
        </div>
    </div>	
    
</section>
