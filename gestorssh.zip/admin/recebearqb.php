<?php
require_once('../pages/system/usuariodb.php');
require_once('../pages/system/bancodb.php');
require_once('../pages/system/senhadb.php');

function conectarBanco($hostname, $username, $password, $database) {
    $conn = new mysqli($hostname, $username, $password, $database);

    if ($conn->connect_error) {
        die('Erro na conexão com o banco de dados: ' . $conn->connect_error);
    }

    return $conn;
}

$hostname = 'localhost';
$username = $usuariodb;
$password = $senhadb;
$database = $bancodb;

if (isset($_FILES['sql_file']) && $_FILES['sql_file']['error'] === UPLOAD_ERR_OK) {
    $tmpFile = $_FILES['sql_file']['tmp_name'];

    $conn = conectarBanco($hostname, $username, $password, $database);

    $sqlContent = file_get_contents($tmpFile);

    if ($conn->multi_query($sqlContent) === true) {
        echo '<script>';
        echo 'alert("Backup restaurado com sucesso!");';
        echo 'window.location.href = window.history.back();';
        echo '</script>';
        exit();
    } else {
        echo '<script>alert("Erro ao restaurar o backup: ' . $conn->error . '");</script>';
    }

    $conn->close();
}
?>
